# Agnes AI Multimodal API Reference

## Base URL
```
https://apihub.agnes-ai.com/v1
```

## Authentication
Bearer token via `Authorization: Bearer YOUR_API_KEY` header.
Obtain key from: https://platform.agnes-ai.com/settings/apiKeys

Compatible with OpenAI Python SDK v1+.

## Image Endpoints

### `POST /v1/images/generations` — Generate Image

#### Request Body (Text-to-Image)
```json
{
  "model": "agnes-image-2.1-flash",
  "prompt": "A golden retriever catching a frisbee in mid-air at sunset",
  "size": "1024x1024",
  "n": 1,
  "response_format": "url",
  "style": "vivid",          // optional: "vivid" or "natural"
  "quality": "standard",     // optional: "standard" or "hd"
  "user": "user-123"         // optional: request ID for troubleshooting
}
```

#### Request Body (Image Editing)
```json
{
  "model": "agnes-image-2.0-flash",
  "prompt": "Change the background to a forest with autumn leaves",
  "size": "1024x1024",
  "image": ["https://..."],   // original image URL or base64 data URI
  "mask": ["..."],             // optional: bounding box coordinates [x,y,w,h]
  "n": 1
}
```

#### Response
```json
{
  "id": "gen_xxxxx",
  "created": 1234567890,
  "data": [
    {
      "url": "https://cdn.agnes-ai.com/generated/img_xxxx.png",
      "b64_json": "...",        // if response_format=b64_json
      "prompt": "original prompt",
      "size": "1024x1024",
      "seed": 42
    }
  ]
}
```

#### Supported Sizes
| Mode | Sizes |
|------|-------|
| Gen 2.1 | 1024x1024, 1024x1536, 1536x1024, 512x512 |
| Edit 2.0 | Same as input image dimensions |

## Video Endpoints

### `POST /v1/videos` — Create Video Task

#### Request Body
```json
{
  "model": "agnes-video-v2.0",
  "prompt": "A majestic wolf howling on a moonlit cliff",
  "image": "https://...",        // optional: for image-to-video
  "width": 1152,
  "height": 768,
  "num_frames": 121,             // REQUIRED: must be 8n+1
  "frame_rate": 24,
  "seed": 42                     // optional: reproducibility
}
```

#### Response (Immediate)
```json
{
  "id": "task_xxxxx",
  "status": "submitted",
  "created_at": "2026-06-21T04:30:00Z",
  "eta_seconds": 60                // estimated time until completion
}
```

### `GET /v1/videos/{task_id}` — Poll Video Status

#### Responses
- **submitted**: Task queued, waiting for processing
- **processing**: Currently generating frames
- **completed**: Video ready
  ```json
  {
    "id": "task_xxxxx",
    "status": "completed",
    "remixed_from_video_id": "https://cdn.agnes-ai.com/video/out_xxxx.mp4"
  }
  ```
- **failed**: Task failed
  ```json
  {
    "id": "task_xxxxx",
    "status": "failed",
    "error": "Content policy violation: prompt contains disallowed content"
  }
  ```

## Error Response Format
```json
{
  "error": {
    "code": 400,
    "message": "Invalid API key",
    "type": "authentication_error",
    "param": "model"           // if applicable
  }
}
```

## Quotas

| Model Type | RPM Limit | Daily Limit |
|------------|-----------|-------------|
| Text (`agnes-2.0-flash`) | 60/min | Unlimited |
| Image 2.1 | 20/min | Unlimited |
| Image 2.0 (edit) | 15/min | Unlimited |
| Video V2.0 | 3/min | 50/day |

Limits are subject to change. Check console at https://platform.agnes-ai.com for real-time usage.
