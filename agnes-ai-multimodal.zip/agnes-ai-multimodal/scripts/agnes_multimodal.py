#!/usr/bin/env python3
"""
Agnes AI Multimodal Helper — text/image/video generation
Usage: python agnes_multimodal.py --help
"""

import argparse
import base64
import json
import os
import sys
import time
from pathlib import Path

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: openai package required. Install: pip install openai")
    sys.exit(1)


DEFAULT_BASE_URL = "https://apihub.agnes-ai.com/v1"
OUTPUT_DIR = Path("output")


def get_client(api_key: str) -> OpenAI:
    """Create and return an OpenAI-compatible client."""
    return OpenAI(api_key=api_key, base_url=DEFAULT_BASE_URL)


def test_key(api_key: str) -> bool:
    """Test API key connectivity with a tiny text generation."""
    try:
        client = get_client(api_key)
        resp = client.chat.completions.create(
            model="agnes-2.0-flash",
            messages=[{"role": "user", "content": "Say hi in 1 word"}],
            max_tokens=5,
        )
        print(f"[OK] API key valid. Response: {resp.choices[0].message.content}")
        return True
    except Exception as e:
        err_msg = str(e)
        if "authentication" in err_msg.lower() or "401" in err_msg:
            print("[FAIL] Invalid or expired API key.")
        elif "429" in err_msg:
            print("[FAIL] RPM limit reached. Wait and retry.")
        else:
            print(f"[FAIL] {err_msg}")
        return False


def gen_image(client: OpenAI, prompt: str, size: str, model: str = "agnes-image-2.1-flash"):
    """Generate an image from text prompt."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    filename = OUTPUT_DIR / f"image_{int(time.time())}.png"

    print(f"Generating image ({model})...")
    print(f"  Size: {size}")

    resp = client.images.generate(model=model, prompt=prompt, size=size, n=1)

    # Save URL for reference
    meta = {"prompt": prompt, "size": size, "model": model, "generated_at": time.strftime("%Y-%m-%d %H:%M:%S")}

    for i, img in enumerate(resp.data):
        meta[f"img_{i}"] = {"url": img.url, "prompt": getattr(img, "prompt", "")}

    with open(filename.with_suffix(".meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    print(f"  Result: {resp.data[0].url}")
    print(f"  Meta saved to: {filename.with_suffix('.meta.json')}")
    print("  Note: Image URLs expire ~24h. Download promptly!")


def edit_image(client: OpenAI, prompt: str, image_url: str, size: str):
    """Edit an existing image."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    filename = OUTPUT_DIR / f"image_edited_{int(time.time())}.png"

    print(f"Editing image with agnes-image-2.0-flash...")
    print(f"  Prompt: {prompt}")
    print(f"  Source: {image_url}")

    resp = client.images.generate(
        model="agnes-image-2.0-flash",
        prompt=prompt,
        size=size,
        n=1,
        extra_body={"image": [image_url]},
    )

    print(f"  Result: {resp.data[0].url}")


def gen_video(client: OpenAI, prompt: str, image_url: str = None, width: int = 1152, height: int = 768, num_frames: int = 121):
    """Generate video (async task + poll)."""
    if num_frames % 8 != 1:
        print(f"ERROR: num_frames must be 8n+1. {num_frames} is invalid. Use 81, 121, 161, 241")
        sys.exit(1)

    body = {
        "model": "agnes-video-v2.0",
        "prompt": prompt,
        "width": width,
        "height": height,
        "num_frames": num_frames,
        "frame_rate": 24,
    }

    if image_url:
        body["image"] = image_url
        print("Creating image-to-video task...")
    else:
        print("Creating text-to-video task...")

    resp = client.post("/videos", body=body)
    task_id = resp["id"]
    print(f"  Task ID: {task_id}")
    print(f"  ETA: {resp.get('eta_seconds', '?')}s")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    meta_file = OUTPUT_DIR / f"video_{task_id}.meta.json"

    while True:
        result = client.get(f"/videos/{task_id}")
        status = result.get("status")
        print(f"  Status: {status}...", end=" ", flush=True)

        if status == "completed":
            video_url = result.get("remixed_from_video_id")
            meta = {"task_id": task_id, "status": "completed", "video_url": video_url, "prompt": prompt}
            with open(meta_file, "w") as f:
                json.dump(meta, f, indent=2)
            print(f"DONE! {video_url}")
            print(f"  Saved meta to: {meta_file}")
            return
        elif status == "failed":
            print(f"FAILED: {result.get('error', 'unknown')}")
            meta = {"task_id": task_id, "status": "failed", "error": result.get("error", "")}
            with open(meta_file, "w") as f:
                json.dump(meta, f, indent=2)
            sys.exit(1)
        else:
            time.sleep(10)


def main():
    parser = argparse.ArgumentParser(
        description="Agnes AI Multimodal — Text/Image/Video Generation Helper",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Test API key
  python %(prog)s --test-key sk-xxxxx

  # Generate image (text-to-image)
  python %(prog)s --image "A cat playing piano in a jazz club" --size 1024x1024 --key sk-xxxxx

  # Edit image
  python %(prog)s --edit-img "Turn this into anime style" --source-url https://... --key sk-xxxxx

  # Generate video (text-to-video)
  python %(prog)s --video "A dog walking on Mars, cinematic wide shot" --key sk-xxxxx

  # Generate video (image-to-video)
  python %(prog)s --video "The waves crash slowly" --source-url https://... --key sk-xxxxx
        """,
    )

    # --- Action groups ---
    parser.add_argument("--test-key", metavar="KEY", help="Test API key connectivity")
    parser.add_argument("--key", "-k", metavar="KEY", help="Your Agnes AI API Key")
    parser.add_argument("--image", "-i", metavar="PROMPT", help="Text-to-image generation prompt")
    parser.add_argument("--size", "-s", default="1024x1024", help="Image size (default: 1024x1024)")
    parser.add_argument("--model-img", default="agnes-image-2.1-flash", help="Image model (default: agnes-image-2.1-flash)")
    parser.add_argument("--edit-img", "-e", metavar="PROMPT", help="Image editing prompt (requires --source-url)")
    parser.add_argument("--source-url", metavar="URL", help="Source image URL for editing/video")
    parser.add_argument("--video", "-v", metavar="PROMPT", help="Video generation prompt (text-to-video)")
    parser.add_argument("--num-frames", default=121, type=int, help="Video frames, must be 8n+1: 81/121/161/241 (default: 121)")

    args = parser.parse_args()

    # --- Logic ---
    if args.test_key:
        sys.exit(0 if test_key(args.test_key) else 1)

    key = args.key or os.environ.get("AGNES_API_KEY")
    if not key:
        parser.error("--key or AGNES_API_KEY env var required")

    client = get_client(key)

    if args.image:
        gen_image(client, args.image, args.size, args.model_img)
    elif args.edit_img:
        if not args.source_url:
            parser.error("--edit-img requires --source-url")
        edit_image(client, args.edit_img, args.source_url, args.size)
    elif args.video:
        gen_video(client, args.video, args.source_url, 1152, 768, args.num_frames)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
