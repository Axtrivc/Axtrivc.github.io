---
name: agnes-ai-multimodal
description: Unified Agnes AI multimodal skill for text, image, and video generation via OpenAI-compatible API. Triggers on: text-to-image, image-to-image, text-to-video, image-to-video, generation, create image, generate video, prompt engineering, sketch-to-image, inpainting, upscaling, video rendering, content creation, and any request to produce visual or multimedia assets using Agnes AI models.
agent_created: true
---

# Agnes AI Multimodal Generation

Generate images and videos from text/image descriptions using Agnes AI's free multimodal API. Supports text-to-image, image editing, text-to-video, and image-to-video with a unified `base_url` and API Key.

## Quick Start

```python
from openai import OpenAI

client = OpenAI(
    api_key="YOUR_AGネス_API_KEY",       # From https://platform.agnes-ai.com/settings/apiKeys
    base_url="https://apihub.agnes-ai.com/v1",
)
```

Same key works for text (`agnes-2.0-flash`), images, and video. No registration fee required.

## Image Generation (Text → Image)

**Model:** `agnes-image-2.1-flash`

```python
resp = client.images.generate(
    model="agnes-image-2.1-flash",
    prompt="A cute kitten playing soccer on a green field under sunny skies, cinematic photography style",
    size="1024x1024",     # Supported: 512x512, 1024x1024, 1024x1536, 1536x1024
    n=1
)
url = resp.data[0].url   # Public URL, lasts ~24h
```

### Prompt Best Practices
- Write in English for best results. Include lighting, composition, mood keywords.
- Describe subject + scene + camera/style + atmosphere.
- Avoid copyrighted characters or brand logos (may trigger policy filter).
- Use negative prompts by passing `extra_body={"negative_prompt": "blurry, deformed hands"}`.

## Image Editing (Image → Image)

**Model:** `agnes-image-2.0-flash` — style transfer, background replacement, local edits.

### Style Transfer / Remaster
```python
resp = client.images.generate(
    model="agnes-image-2.0-flash",
    prompt="Convert this illustration into a watercolor painting style, keep the subject and colors similar",
    size="1024x1024",
    extra_body={
        "image": [original_url]   # Array of image URLs or base64
    }
)
```

### Inpainting / Local Editing
Specify the region with prompt instructions (e.g., "Replace the sky with sunset clouds, keep everything else unchanged").

### Batch Edit
```python
resp = client.images.generate(
    model="agnes-image-2.0-flash",
    prompt="Change background to beach, add sunglasses",
    size="1024x1024",
    extra_body={
        "image": [url1, url2]       # Multiple inputs
    }
)
```

## Video Generation (Text/Image → Video)

**Model:** `agnes-video-v2.0` — Audio-sync video generation, cinematic quality.

### Async Task Pattern
Video API uses `/v1/videos` endpoint with task polling:

```python
import time
import httpx

# Step 1: Create task
resp = client.post(
    "/videos",
    body={
        "model": "agnes-video-v2.0",
        "prompt": "A cute kitten kicking a soccer ball on an evening stadium, audience in stands, floodlights glowing, cinematic",
        "image": image_url,           # Optional: for image-to-video mode
        "width": 1152,
        "height": 768,
        "num_frames": 121,            # MUST be 8n+1: 81, 121, 161, 241
        "frame_rate": 24
    }
)
task_id = resp["id"]

# Step 2: Poll until complete
while True:
    result = client.get(f"/videos/{task_id}")
    if result["status"] == "completed":
        video_url = result["remixed_from_video_id"]   # Final video URL
        break
    elif result["status"] == "failed":
        raise RuntimeError(f"Video generation failed: {result.get('error')}")
    time.sleep(10)
```

### Video Parameter Constraints
| Parameter | Allowed Values |
|-----------|---------------|
| `num_frames` | Must be `8n+1`: **81, 121, 161, 241** |
| `frame_rate` | 12, 24, 30 |
| `width` | 512, 720, 1024, 1152, 1280, 1536 |
| `height` | 512, 768, 1024, 1152, 1280, 1536 |
| `width × height` ratio | Any portrait/landscape square; common: `1152×768` or `768×1152` |

### Tips for Better Video
- Describe motion explicitly: "slow pan left", "zoom in", "character walks forward"
- Specify camera angle: "wide shot", "close-up", "overhead drone view"
- Mention pacing: "smooth transitions", "fast-paced cuts"
- For text-to-video: keep prompt under 300 characters

## RPM Limits (Free Tier)
- **Text**: High RPM (typically 100+/min)
- **Image**: Moderate RPM (typically 10-30/min)
- **Video**: Low RPM (typically 2-5/min), async with queuing

When hitting limits: wait a few seconds, then retry. Use exponential backoff for video polls.

## Error Handling

| HTTP Code | Meaning | Fix |
|-----------|---------|-----|
| 401 | Invalid/expired API Key | Regenerate at platform.agnes-ai.com |
| 429 | RPM exceeded | Retry after delay |
| 400 | Bad request / policy violation | Simplify prompt, remove restricted content |
| 500 | Server error | Retry once; if persists, check status page |

For image API errors: `resp.json()["error"]["message"]`

For video: check `result["status"] == "failed"` and read `result.get("error")`.

## Python Wrapper Script

For convenience, a helper script is provided:

- Run `python scripts/agnes_multimodal.py --help` for usage.
- Script handles: text-to-image, image-editing, text-to-video, image-to-video, result polling.
- Saves outputs to `output/` directory.

## Workflow

1. **Create API Key** — Go to https://platform.agnes-ai.com → Settings → API Keys → "Create New Secret"
2. **Test connectivity** — Run `python scripts/agnes_multimodal.py --test-key` with the key
3. **Generate** — Use the script or direct OpenAI client calls as shown above
4. **Download** — Images expire after ~24h; download promptly. Videos persist until deleted.

## Troubleshooting

- **API Key not accepted**: Ensure key starts with `sk-` prefix. Copy-paste carefully (no trailing spaces).
- **Image generation empty**: Prompt may hit content filter. Simplify and retry.
- **Video poll timeout**: Increase `num_frames` to smaller value (81). Server may be busy.
- **Base URL wrong**: Must be `https://apihub.agnes-ai.com/v1`, not `platform.agnes-ai.com`.
- **Size mismatch**: For image edit, `size` must match input image aspect ratio.
